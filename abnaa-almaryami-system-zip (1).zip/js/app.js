// ============================================================
// منظومة أبناء المريمي - معرض السيارات
// نظام متكامل: بيع، شراء، صيانة، مخزن، فواتير، مصاريف، مراقبة
// ============================================================

// ===================== DEFAULT DATA =====================
const DEFAULT_USERS = [
    { id: 'admin', username: 'admin', fullname: 'المشرف العام', password: 'admin123', role: 'admin', active: true, lastLogin: null, perms: { cars: true, sales: true, purchases: true, maintenance: true, inventory: true, invoices: true, expenses: true, reports: true, users: true, monitoring: true } },
    { id: 'manager1', username: 'manager', fullname: 'مدير الفرع', password: 'manager123', role: 'manager', active: true, lastLogin: null, perms: { cars: true, sales: true, purchases: true, maintenance: true, inventory: true, invoices: true, expenses: true, reports: true, users: false, monitoring: false } },
    { id: 'sales1', username: 'sales', fullname: 'أحمد - المبيعات', password: 'sales123', role: 'sales', active: true, lastLogin: null, perms: { cars: true, sales: true, purchases: false, maintenance: false, inventory: false, invoices: true, expenses: false, reports: false, users: false, monitoring: false } },
    { id: 'accountant1', username: 'accountant', fullname: 'محمد - المحاسب', password: 'acc123', role: 'accountant', active: true, lastLogin: null, perms: { cars: false, sales: true, purchases: true, maintenance: false, inventory: true, invoices: true, expenses: true, reports: true, users: false, monitoring: false } },
    { id: 'viewer1', username: 'viewer', fullname: 'زائر', password: 'view123', role: 'viewer', active: true, lastLogin: null, perms: { cars: true, sales: false, purchases: false, maintenance: false, inventory: false, invoices: false, expenses: false, reports: true, users: false, monitoring: false } },
];

const DEFAULT_CARS = [
    { id: 'car1', brand: 'Toyota', model: 'Camry 2020', year: 2020, color: 'أبيض', plate: '1-12345', price: 8500000, status: 'available', fuel: 'gasoline', images: [], pdf: '', notes: 'سيارة بحالة ممتازة', dateAdded: '2024-01-15' },
    { id: 'car2', brand: 'Honda', model: 'Civic 2022', year: 2022, color: 'رمادي', plate: '2-23456', price: 7200000, status: 'available', fuel: 'gasoline', images: [], pdf: '', notes: 'كامل المواصفات', dateAdded: '2024-02-10' },
    { id: 'car3', brand: 'Hyundai', model: 'Tucson 2021', year: 2021, color: 'أسود', plate: '3-34567', price: 9500000, status: 'available', fuel: 'gasoline', images: [], pdf: '', notes: 'دفع رباعي', dateAdded: '2024-03-05' },
    { id: 'car4', brand: 'Lexus', model: 'RX 350 2019', year: 2019, color: 'فضي', plate: '4-45678', price: 12500000, status: 'available', fuel: 'gasoline', images: [], pdf: '', notes: 'فخمة ونظيفة', dateAdded: '2024-03-20' },
];

const DEFAULT_SALES = [
    { id: 's1', carId: 'car5', carName: 'Toyota Corolla 2018', customer: 'علي محمد', phone: '777-111-222', price: 6200000, payment: 'cash', date: '2024-03-01', status: 'completed', notes: 'تم البيع بنجاح' },
];

const DEFAULT_PURCHASES = [
    { id: 'p1', carName: 'Nissan Altima 2021', supplier: 'معرض الخليج', phone: '733-444-555', price: 5800000, payment: 'transfer', date: '2024-02-15', status: 'completed', notes: 'جيدة' },
];

const DEFAULT_MAINTENANCE = [
    { id: 'm1', carId: 'car2', carName: 'Honda Civic 2022', type: 'periodic', cost: 150000, date: '2024-03-10', status: 'done', desc: 'صيانة دورية: تغيير زيت + فلاتر' },
];

const DEFAULT_INVENTORY = [
    { id: 'inv1', name: 'فلتر زيت', type: 'spare', qty: 50, price: 5000, location: 'رف A1' },
    { id: 'inv2', name: 'زيت محرك', type: 'material', qty: 30, price: 25000, location: 'رف A2' },
    { id: 'inv3', name: 'فرامل أمامية', type: 'spare', qty: 20, price: 45000, location: 'رف B1' },
];

const DEFAULT_INVOICES = [
    { id: 'inv001', number: 'F-2024-001', type: 'sale', party: 'علي محمد', amount: 6200000, items: [{desc: 'Toyota Corolla 2018', qty: 1, price: 6200000, total: 6200000}], discount: 0, total: 6200000, date: '2024-03-01', status: 'paid', notes: 'فاتورة بيع' },
];

const DEFAULT_EXPENSES = [
    { id: 'e1', item: 'إيجار المعرض', type: 'rent', amount: 500000, date: '2024-03-01', notes: 'إيجار شهري' },
    { id: 'e2', item: 'رواتب الموظفين', type: 'salary', amount: 1200000, date: '2024-03-01', notes: 'رواتب شهر مارس' },
];

const DEFAULT_LOGS = [
    { id: 'l1', time: '2024-03-01 09:00', user: 'admin', action: 'تسجيل دخول', detail: 'دخول النظام', ip: '192.168.1.1' },
];

const DEFAULT_SHOWROOM = {
    name: 'أبناء المريمي',
    phone1: '777-123-456',
    phone2: '733-987-654',
    address: 'صنعاء - شارع الستين - جوار محطة البترول',
    email: 'info@almaryami.com'
};

// ===================== STORAGE HELPERS =====================
function getDB() {
    const db = localStorage.getItem('almaryami_db');
    if (db) return JSON.parse(db);
    const initial = {
        users: JSON.parse(JSON.stringify(DEFAULT_USERS)),
        cars: JSON.parse(JSON.stringify(DEFAULT_CARS)),
        sales: JSON.parse(JSON.stringify(DEFAULT_SALES)),
        purchases: JSON.parse(JSON.stringify(DEFAULT_PURCHASES)),
        maintenance: JSON.parse(JSON.stringify(DEFAULT_MAINTENANCE)),
        inventory: JSON.parse(JSON.stringify(DEFAULT_INVENTORY)),
        invoices: JSON.parse(JSON.stringify(DEFAULT_INVOICES)),
        expenses: JSON.parse(JSON.stringify(DEFAULT_EXPENSES)),
        logs: JSON.parse(JSON.stringify(DEFAULT_LOGS)),
        showroom: JSON.parse(JSON.stringify(DEFAULT_SHOWROOM)),
        settings: { logAll: true, alertLogin: true, confirmDelete: true }
    };
    saveDB(initial);
    return initial;
}

function saveDB(db) {
    localStorage.setItem('almaryami_db', JSON.stringify(db));
}

function addLog(action, detail) {
    const db = getDB();
    const user = currentUser ? currentUser.username : 'guest';
    db.logs.unshift({
        id: 'l' + Date.now(),
        time: new Date().toLocaleString('ar-YE'),
        user: user,
        action: action,
        detail: detail,
        ip: '127.0.0.1'
    });
    saveDB(db);
}

// ===================== AUTH =====================
let currentUser = null;
let currentDB = getDB();

const PERM_MAP = {
    'cars': 'perm-cars', 'sales': 'perm-sales', 'purchases': 'perm-purchases',
    'maintenance': 'perm-maintenance', 'inventory': 'perm-inventory',
    'invoices': 'perm-invoices', 'expenses': 'perm-expenses', 'reports': 'perm-reports',
    'users': 'perm-users', 'monitoring': 'perm-monitoring'
};

const ROLE_LABELS = {
    'admin': 'مدير', 'manager': 'مدير فرع', 'sales': 'مبيعات',
    'accountant': 'محاسب', 'viewer': 'مشاهد'
};

const STATUS_LABELS = {
    'available': 'متوفرة', 'sold': 'مباعة', 'maintenance': 'قيد الصيانة', 'reserved': 'محجوزة',
    'completed': 'مكتملة', 'pending': 'معلقة', 'cancelled': 'ملغاة',
    'paid': 'مدفوعة', 'done': 'منتهية', 'in-progress': 'قيد التنفيذ'
};

function login(username, password) {
    const db = getDB();
    const user = db.users.find(u => u.username === username && u.password === password && u.active);
    if (!user) return false;
    currentUser = user;
    user.lastLogin = new Date().toLocaleString('ar-YE');
    saveDB(db);
    addLog('تسجيل دخول', `دخول المستخدم ${user.fullname}`);
    return true;
}

function logout() {
    if (currentUser) addLog('تسجيل خروج', `خروج المستخدم ${currentUser.fullname}`);
    currentUser = null;
    showScreen('login');
}

function hasPermission(perm) {
    if (!currentUser) return false;
    if (currentUser.role === 'admin') return true;
    return currentUser.perms && currentUser.perms[perm];
}

// ===================== UI =====================
function showScreen(screen) {
    document.getElementById('login-screen').classList.toggle('hidden', screen !== 'login');
    document.getElementById('dashboard').classList.toggle('hidden', screen !== 'dashboard');
}

function showPage(page) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    // Show target page
    const target = document.getElementById('page-' + page);
    if (target) target.classList.add('active');
    // Update nav
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const nav = document.querySelector('.nav-item[data-page="' + page + '"]');
    if (nav) nav.classList.add('active');
    // Update title
    const titles = {
        'home': 'لوحة التحكم', 'cars': 'إدارة السيارات', 'sales': 'المبيعات',
        'purchases': 'المشتريات', 'maintenance': 'الصيانة', 'inventory': 'المخزن',
        'invoices': 'الفواتير', 'expenses': 'المصاريف', 'reports': 'التقارير',
        'monitoring': 'المراقبة', 'users': 'المستخدمين', 'settings': 'الإعدادات'
    };
    document.getElementById('page-title').textContent = titles[page] || '';
    // Refresh page data
    refreshPage(page);
}

function refreshPage(page) {
    switch(page) {
        case 'home': updateHomeStats(); break;
        case 'cars': updateCars(); break;
        case 'sales': updateSales(); break;
        case 'purchases': updatePurchases(); break;
        case 'maintenance': updateMaintenance(); break;
        case 'inventory': updateInventory(); break;
        case 'invoices': updateInvoices(); break;
        case 'expenses': updateExpenses(); break;
        case 'monitoring': updateMonitoring(); break;
        case 'users': updateUsers(); break;
    }
}

function updateHomeStats() {
    const db = getDB();
    document.getElementById('stat-cars').textContent = db.cars.filter(c => c.status === 'available').length;
    document.getElementById('stat-sales').textContent = db.sales.length;
    document.getElementById('stat-revenue').textContent = formatNumber(db.sales.reduce((s, x) => s + x.price, 0)) + ' ر.ي';
    document.getElementById('stat-maintenance').textContent = db.maintenance.filter(m => m.status === 'in-progress').length;
    document.getElementById('stat-inventory').textContent = db.inventory.length;
    document.getElementById('stat-invoices').textContent = db.invoices.length;
    // Recent sales
    const recentSales = db.sales.slice(0, 5);
    const recentContainer = document.getElementById('recent-sales');
    recentContainer.innerHTML = recentSales.length ? '' : '<p style="color:var(--gray);text-align:center;">لا توجد مبيعات بعد</p>';
    recentSales.forEach(s => {
        recentContainer.innerHTML += `
            <div class="recent-item">
                <div class="recent-item-info">
                    <h4>${s.carName}</h4>
                    <span>${s.customer} - ${s.date}</span>
                </div>
                <div class="recent-item-price">${formatNumber(s.price)}</div>
            </div>`;
    });
    // Alerts
    const alerts = [];
    const lowInventory = db.inventory.filter(i => i.qty < 10);
    if (lowInventory.length) alerts.push({ type: 'warning', text: `${lowInventory.length} قطع منخفضة في المخزن` });
    if (db.cars.filter(c => c.status === 'maintenance').length) alerts.push({ type: 'info', text: `${db.cars.filter(c => c.status === 'maintenance').length} سيارة في الصيانة` });
    const pendingInvoices = db.invoices.filter(i => i.status === 'pending');
    if (pendingInvoices.length) alerts.push({ type: 'danger', text: `${pendingInvoices.length} فاتورة معلقة` });
    const alertsContainer = document.getElementById('alerts-list');
    alertsContainer.innerHTML = alerts.length ? '' : '<p style="color:var(--gray);text-align:center;">لا توجد تنبيهات</p>';
    alerts.forEach(a => {
        alertsContainer.innerHTML += `<div class="alert-item ${a.type}"><i class="fas fa-exclamation-circle"></i> ${a.text}</div>`;
    });
}

// ===================== CARS =====================
function updateCars() {
    if (!hasPermission('cars')) return;
    const db = getDB();
    const search = document.getElementById('car-search')?.value?.toLowerCase() || '';
    const filtered = db.cars.filter(c =>
        !search || c.brand.toLowerCase().includes(search) || c.model.toLowerCase().includes(search) || c.plate.includes(search)
    );
    const container = document.getElementById('cars-list');
    container.innerHTML = '';
    filtered.forEach(c => {
        const brandIcon = getBrandIcon(c.brand);
        container.innerHTML += `
            <div class="car-card">
                <div class="car-image">
                    ${c.images.length ? `<img src="${c.images[0]}" alt="">` : `<i class="fas ${brandIcon}"></i>`}
                    <span class="car-status-badge ${c.status}">${STATUS_LABELS[c.status]}</span>
                </div>
                <div class="car-info">
                    <h3>${c.brand} ${c.model}</h3>
                    <div class="car-details">
                        <span><i class="fas fa-calendar"></i> ${c.year}</span>
                        <span><i class="fas fa-palette"></i> ${c.color}</span>
                        <span><i class="fas fa-gas-pump"></i> ${c.fuel === 'gasoline' ? 'بنزين' : c.fuel === 'diesel' ? 'ديزل' : c.fuel === 'hybrid' ? 'هايبرد' : 'كهربائي'}</span>
                        <span><i class="fas fa-id-card"></i> ${c.plate}</span>
                    </div>
                    <div class="car-price">${formatNumber(c.price)} ر.ي</div>
                </div>
                <div class="car-actions">
                    <button class="btn-edit" onclick="editCar('${c.id}')"><i class="fas fa-edit"></i> تعديل</button>
                    <button class="btn-sell" onclick="quickSell('${c.id}')"><i class="fas fa-handshake"></i> بيع</button>
                    <button class="btn-delete" onclick="deleteCar('${c.id}')"><i class="fas fa-trash"></i></button>
                </div>
            </div>`;
    });
    if (!filtered.length) container.innerHTML = '<div style="text-align:center;color:var(--gray);padding:40px;"><i class="fas fa-car" style="font-size:40px;margin-bottom:15px;display:block;"></i>لا توجد سيارات</div>';
}

function getBrandIcon(brand) {
    const map = { 'Toyota': 'fa-car-side', 'Honda': 'fa-car', 'Nissan': 'fa-truck', 'Hyundai': 'fa-car', 'Kia': 'fa-car', 'Mercedes': 'fa-car', 'BMW': 'fa-car', 'Lexus': 'fa-car', 'Mitsubishi': 'fa-truck-pickup', 'Ford': 'fa-truck', 'Chevrolet': 'fa-truck' };
    return map[brand] || 'fa-car';
}

function showCarModal() {
    if (!hasPermission('cars')) return alert('لا يوجد صلاحية!');
    document.getElementById('car-modal-title').textContent = 'إضافة سيارة';
    document.getElementById('car-form').reset();
    document.getElementById('car-id').value = '';
    document.getElementById('image-preview').innerHTML = '';
    document.getElementById('pdf-preview').innerHTML = '';
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('car-modal').classList.remove('hidden');
}

function editCar(id) {
    if (!hasPermission('cars')) return alert('لا يوجد صلاحية!');
    const db = getDB();
    const car = db.cars.find(c => c.id === id);
    if (!car) return;
    document.getElementById('car-modal-title').textContent = 'تعديل سيارة';
    document.getElementById('car-id').value = car.id;
    document.getElementById('car-brand').value = car.brand;
    document.getElementById('car-model').value = car.model;
    document.getElementById('car-year').value = car.year;
    document.getElementById('car-color').value = car.color;
    document.getElementById('car-plate').value = car.plate;
    document.getElementById('car-price').value = car.price;
    document.getElementById('car-status').value = car.status;
    document.getElementById('car-fuel').value = car.fuel;
    document.getElementById('car-notes').value = car.notes || '';
    document.getElementById('image-preview').innerHTML = car.images.map(img => `<img src="${img}" alt="">`).join('');
    document.getElementById('pdf-preview').innerHTML = car.pdf ? `<a href="${car.pdf}" target="_blank"><i class="fas fa-file-pdf"></i> عرض الملف</a>` : '';
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('car-modal').classList.remove('hidden');
}

function deleteCar(id) {
    if (!hasPermission('cars')) return alert('لا يوجد صلاحية!');
    if (currentDB.settings.confirmDelete && !confirm('هل أنت متأكد من حذف هذه السيارة؟')) return;
    const db = getDB();
    db.cars = db.cars.filter(c => c.id !== id);
    saveDB(db);
    addLog('حذف سيارة', `حذف السيارة ${id}`);
    updateCars();
    updateHomeStats();
}

function quickSell(carId) {
    if (!hasPermission('sales')) return alert('لا يوجد صلاحية!');
    showPage('sales');
    showSaleModal();
    document.getElementById('sale-car').value = carId;
}

// ===================== SALES =====================
function updateSales() {
    if (!hasPermission('sales')) return;
    const db = getDB();
    const tbody = document.querySelector('#sales-table tbody');
    tbody.innerHTML = db.sales.map(s => `
        <tr>
            <td>${s.id}</td>
            <td>${s.carName}</td>
            <td>${s.customer}</td>
            <td>${formatNumber(s.price)}</td>
            <td>${s.date}</td>
            <td><span class="status-badge ${s.status}">${STATUS_LABELS[s.status]}</span></td>
            <td>
                <div class="table-actions">
                    <button class="btn-edit" onclick="editSale('${s.id}')"><i class="fas fa-edit"></i></button>
                    <button class="btn-delete" onclick="deleteSale('${s.id}')"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        </tr>
    `).join('');
    if (!db.sales.length) tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--gray);padding:30px;">لا توجد مبيعات</td></tr>';
}

function showSaleModal() {
    if (!hasPermission('sales')) return alert('لا يوجد صلاحية!');
    document.getElementById('sale-form').reset();
    document.getElementById('sale-id').value = '';
    const db = getDB();
    const carSelect = document.getElementById('sale-car');
    carSelect.innerHTML = '<option value="">اختر السيارة...</option>' + db.cars.filter(c => c.status === 'available').map(c => `<option value="${c.id}">${c.brand} ${c.model} (${c.plate})</option>`).join('');
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('sale-modal').classList.remove('hidden');
}

function editSale(id) { /* similar pattern */ }
function deleteSale(id) {
    if (!hasPermission('sales')) return;
    const db = getDB();
    db.sales = db.sales.filter(s => s.id !== id);
    saveDB(db);
    addLog('حذف بيع', id);
    updateSales();
    updateHomeStats();
}

// ===================== PURCHASES =====================
function updatePurchases() {
    if (!hasPermission('purchases')) return;
    const db = getDB();
    const tbody = document.querySelector('#purchases-table tbody');
    tbody.innerHTML = db.purchases.map(p => `
        <tr>
            <td>${p.id}</td>
            <td>${p.carName}</td>
            <td>${p.supplier}</td>
            <td>${formatNumber(p.price)}</td>
            <td>${p.date}</td>
            <td><span class="status-badge ${p.status}">${STATUS_LABELS[p.status]}</span></td>
            <td>
                <div class="table-actions">
                    <button class="btn-edit" onclick="editPurchase('${p.id}')"><i class="fas fa-edit"></i></button>
                    <button class="btn-delete" onclick="deletePurchase('${p.id}')"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        </tr>
    `).join('');
    if (!db.purchases.length) tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--gray);padding:30px;">لا توجد مشتريات</td></tr>';
}

function showPurchaseModal() {
    if (!hasPermission('purchases')) return alert('لا يوجد صلاحية!');
    document.getElementById('purchase-form').reset();
    document.getElementById('purchase-id').value = '';
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('purchase-modal').classList.remove('hidden');
}

function deletePurchase(id) {
    if (!hasPermission('purchases')) return;
    const db = getDB();
    db.purchases = db.purchases.filter(p => p.id !== id);
    saveDB(db);
    addLog('حذف شراء', id);
    updatePurchases();
}

// ===================== MAINTENANCE =====================
function updateMaintenance() {
    if (!hasPermission('maintenance')) return;
    const db = getDB();
    const tbody = document.querySelector('#maintenance-table tbody');
    tbody.innerHTML = db.maintenance.map(m => `
        <tr>
            <td>${m.id}</td>
            <td>${m.carName}</td>
            <td>${m.type === 'periodic' ? 'دورية' : m.type === 'engine' ? 'محرك' : m.type === 'body' ? 'هيكل' : m.type === 'electrical' ? 'كهرباء' : m.type === 'paint' ? 'دهان' : 'أخرى'}</td>
            <td>${formatNumber(m.cost)}</td>
            <td>${m.date}</td>
            <td><span class="status-badge ${m.status}">${STATUS_LABELS[m.status]}</span></td>
            <td>
                <div class="table-actions">
                    <button class="btn-edit" onclick="editMaintenance('${m.id}')"><i class="fas fa-edit"></i></button>
                    <button class="btn-delete" onclick="deleteMaintenance('${m.id}')"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        </tr>
    `).join('');
    if (!db.maintenance.length) tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--gray);padding:30px;">لا توجد صيانات</td></tr>';
}

function showMaintenanceModal() {
    if (!hasPermission('maintenance')) return alert('لا يوجد صلاحية!');
    document.getElementById('maintenance-form').reset();
    document.getElementById('maintenance-id').value = '';
    const db = getDB();
    const carSelect = document.getElementById('maintenance-car');
    carSelect.innerHTML = '<option value="">اختر السيارة...</option>' + db.cars.map(c => `<option value="${c.id}">${c.brand} ${c.model} (${c.plate})</option>`).join('');
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('maintenance-modal').classList.remove('hidden');
}

function deleteMaintenance(id) {
    if (!hasPermission('maintenance')) return;
    const db = getDB();
    db.maintenance = db.maintenance.filter(m => m.id !== id);
    saveDB(db);
    addLog('حذف صيانة', id);
    updateMaintenance();
}

// ===================== INVENTORY =====================
function updateInventory() {
    if (!hasPermission('inventory')) return;
    const db = getDB();
    const tbody = document.querySelector('#inventory-table tbody');
    tbody.innerHTML = db.inventory.map(i => `
        <tr>
            <td>${i.id}</td>
            <td>${i.name}</td>
            <td>${i.type === 'spare' ? 'قطعة غيار' : i.type === 'accessory' ? 'إكسسوار' : i.type === 'tool' ? 'أداة' : 'مادة'}</td>
            <td>${i.qty}</td>
            <td>${formatNumber(i.price)}</td>
            <td>${i.location}</td>
            <td>
                <div class="table-actions">
                    <button class="btn-edit" onclick="editInventory('${i.id}')"><i class="fas fa-edit"></i></button>
                    <button class="btn-delete" onclick="deleteInventory('${i.id}')"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        </tr>
    `).join('');
    if (!db.inventory.length) tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--gray);padding:30px;">لا يوجد مخزون</td></tr>';
}

function showInventoryModal() {
    if (!hasPermission('inventory')) return alert('لا يوجد صلاحية!');
    document.getElementById('inventory-form').reset();
    document.getElementById('inventory-id').value = '';
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('inventory-modal').classList.remove('hidden');
}

function deleteInventory(id) {
    if (!hasPermission('inventory')) return;
    const db = getDB();
    db.inventory = db.inventory.filter(i => i.id !== id);
    saveDB(db);
    addLog('حذف من المخزن', id);
    updateInventory();
    updateHomeStats();
}

// ===================== INVOICES =====================
function updateInvoices() {
    if (!hasPermission('invoices')) return;
    const db = getDB();
    const tbody = document.querySelector('#invoices-table tbody');
    tbody.innerHTML = db.invoices.map(inv => `
        <tr>
            <td>${inv.number}</td>
            <td>${inv.type === 'sale' ? 'فاتورة بيع' : inv.type === 'purchase' ? 'فاتورة شراء' : inv.type === 'maintenance' ? 'فاتورة صيانة' : 'أخرى'}</td>
            <td>${inv.party}</td>
            <td>${formatNumber(inv.total)}</td>
            <td>${inv.date}</td>
            <td><span class="status-badge ${inv.status}">${STATUS_LABELS[inv.status]}</span></td>
            <td>
                <div class="table-actions">
                    <button class="btn-view" onclick="viewInvoice('${inv.id}')"><i class="fas fa-eye"></i></button>
                    <button class="btn-print" onclick="printInvoiceById('${inv.id}')"><i class="fas fa-print"></i></button>
                    <button class="btn-delete" onclick="deleteInvoice('${inv.id}')"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        </tr>
    `).join('');
    if (!db.invoices.length) tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--gray);padding:30px;">لا توجد فواتير</td></tr>';
}

function showInvoiceModal() {
    if (!hasPermission('invoices')) return alert('لا يوجد صلاحية!');
    document.getElementById('invoice-form').reset();
    document.getElementById('invoice-id').value = '';
    document.getElementById('invoice-number').value = 'F-' + new Date().getFullYear() + '-' + String(getDB().invoices.length + 1).padStart(3, '0');
    document.getElementById('invoice-items').innerHTML = `
        <div class="invoice-item-row">
            <input type="text" placeholder="البيان" class="item-desc">
            <input type="number" placeholder="الكمية" class="item-qty" value="1">
            <input type="number" placeholder="السعر" class="item-price">
            <input type="number" placeholder="الإجمالي" class="item-total" readonly>
        </div>`;
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('invoice-modal').classList.remove('hidden');
}

function addInvoiceItem() {
    document.getElementById('invoice-items').insertAdjacentHTML('beforeend', `
        <div class="invoice-item-row">
            <input type="text" placeholder="البيان" class="item-desc">
            <input type="number" placeholder="الكمية" class="item-qty" value="1">
            <input type="number" placeholder="السعر" class="item-price">
            <input type="number" placeholder="الإجمالي" class="item-total" readonly>
        </div>`);
}

function calculateInvoiceTotal() {
    let total = 0;
    document.querySelectorAll('.invoice-item-row').forEach(row => {
        const qty = parseFloat(row.querySelector('.item-qty').value) || 0;
        const price = parseFloat(row.querySelector('.item-price').value) || 0;
        const rowTotal = qty * price;
        row.querySelector('.item-total').value = rowTotal;
        total += rowTotal;
    });
    const discount = parseFloat(document.getElementById('invoice-discount').value) || 0;
    document.getElementById('invoice-total').value = total - discount;
}

function viewInvoice(id) { /* view logic */ }

function printInvoiceById(id) {
    const db = getDB();
    const inv = db.invoices.find(i => i.id === id);
    if (!inv) return;
    generatePrintInvoice(inv);
}

function printInvoice() {
    const inv = {
        number: document.getElementById('invoice-number').value,
        type: document.getElementById('invoice-type').value,
        party: document.getElementById('invoice-party').value,
        date: new Date().toLocaleDateString('ar-YE'),
        items: Array.from(document.querySelectorAll('.invoice-item-row')).map(row => ({
            desc: row.querySelector('.item-desc').value,
            qty: row.querySelector('.item-qty').value,
            price: row.querySelector('.item-price').value,
            total: row.querySelector('.item-total').value
        })),
        discount: document.getElementById('invoice-discount').value || 0,
        total: document.getElementById('invoice-total').value || 0,
        status: document.getElementById('invoice-status').value,
        notes: document.getElementById('invoice-notes').value
    };
    generatePrintInvoice(inv);
}

function generatePrintInvoice(inv) {
    const db = getDB();
    const sr = db.showroom;
    const itemsHtml = inv.items.map(item => `
        <tr><td>${item.desc}</td><td>${item.qty}</td><td>${formatNumber(item.price)}</td><td>${formatNumber(item.total)}</td></tr>
    `).join('');
    document.getElementById('invoice-print-content').innerHTML = `
        <div class="invoice-header">
            <div class="logo-car-print"><i class="fas fa-car"></i></div>
            <h1>${sr.name}</h1>
            <p>معرض السيارات</p>
            <p><i class="fas fa-phone"></i> ${sr.phone1} | <i class="fas fa-map-marker-alt"></i> ${sr.address}</p>
        </div>
        <div class="invoice-details">
            <div class="invoice-details-box">
                <h4>رقم الفاتورة</h4>
                <p>${inv.number}</p>
            </div>
            <div class="invoice-details-box">
                <h4>التاريخ</h4>
                <p>${inv.date}</p>
            </div>
            <div class="invoice-details-box">
                <h4>النوع</h4>
                <p>${inv.type === 'sale' ? 'فاتورة بيع' : inv.type === 'purchase' ? 'فاتورة شراء' : inv.type === 'maintenance' ? 'فاتورة صيانة' : 'أخرى'}</p>
            </div>
            <div class="invoice-details-box">
                <h4>الجهة</h4>
                <p>${inv.party}</p>
            </div>
        </div>
        <table class="invoice-table">
            <thead><tr><th>البيان</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead>
            <tbody>${itemsHtml}</tbody>
        </table>
        <div class="invoice-total">الإجمالي: ${formatNumber(inv.total)} ر.ي</div>
        <div class="invoice-footer">
            <p>شكراً لتعاملكم معنا</p>
            <p>${sr.name} | ${sr.phone1} | ${sr.address}</p>
        </div>
    `;
    document.getElementById('invoice-print').classList.remove('hidden');
}

function closePrintModal() {
    document.getElementById('invoice-print').classList.add('hidden');
}

function deleteInvoice(id) {
    if (!hasPermission('invoices')) return;
    const db = getDB();
    db.invoices = db.invoices.filter(i => i.id !== id);
    saveDB(db);
    addLog('حذف فاتورة', id);
    updateInvoices();
}

// ===================== EXPENSES =====================
function updateExpenses() {
    if (!hasPermission('expenses')) return;
    const db = getDB();
    const tbody = document.querySelector('#expenses-table tbody');
    tbody.innerHTML = db.expenses.map(e => `
        <tr>
            <td>${e.id}</td>
            <td>${e.item}</td>
            <td>${e.type === 'rent' ? 'إيجار' : e.type === 'salary' ? 'رواتب' : e.type === 'utility' ? 'فواتير خدمات' : e.type === 'marketing' ? 'تسويق' : e.type === 'tax' ? 'ضرائب' : 'أخرى'}</td>
            <td>${formatNumber(e.amount)}</td>
            <td>${e.date}</td>
            <td>
                <div class="table-actions">
                    <button class="btn-edit" onclick="editExpense('${e.id}')"><i class="fas fa-edit"></i></button>
                    <button class="btn-delete" onclick="deleteExpense('${e.id}')"><i class="fas fa-trash"></i></button>
                </div>
            </td>
        </tr>
    `).join('');
    if (!db.expenses.length) tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--gray);padding:30px;">لا توجد مصاريف</td></tr>';
}

function showExpenseModal() {
    if (!hasPermission('expenses')) return alert('لا يوجد صلاحية!');
    document.getElementById('expense-form').reset();
    document.getElementById('expense-id').value = '';
    document.getElementById('expense-date').value = new Date().toISOString().split('T')[0];
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('expense-modal').classList.remove('hidden');
}

function deleteExpense(id) {
    if (!hasPermission('expenses')) return;
    const db = getDB();
    db.expenses = db.expenses.filter(e => e.id !== id);
    saveDB(db);
    addLog('حذف مصروف', id);
    updateExpenses();
}

// ===================== MONITORING =====================
function updateMonitoring() {
    if (!hasPermission('monitoring')) return;
    const db = getDB();
    const filter = document.querySelector('.btn-filter.active')?.dataset?.filter || 'all';
    let logs = db.logs;
    if (filter !== 'all') {
        logs = logs.filter(l => l.action.toLowerCase().includes(filter) || l.detail.toLowerCase().includes(filter));
    }
    const tbody = document.querySelector('#monitoring-table tbody');
    tbody.innerHTML = logs.map(l => `
        <tr>
            <td>${l.time}</td>
            <td>${l.user}</td>
            <td>${l.action}</td>
            <td>${l.detail}</td>
            <td>${l.ip}</td>
        </tr>
    `).join('');
    if (!logs.length) tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--gray);padding:30px;">لا توجد سجلات</td></tr>';
}

// ===================== USERS =====================
function updateUsers() {
    if (!hasPermission('users')) return;
    const db = getDB();
    const tbody = document.querySelector('#users-table tbody');
    tbody.innerHTML = db.users.map(u => `
        <tr>
            <td>${u.username}</td>
            <td>${u.fullname}</td>
            <td>${ROLE_LABELS[u.role] || u.role}</td>
            <td><span class="status-badge ${u.active ? 'active' : 'inactive'}">${u.active ? 'نشط' : 'معطل'}</span></td>
            <td>${u.lastLogin || '—'}</td>
            <td>
                <div class="table-actions">
                    <button class="btn-edit" onclick="editUser('${u.id}')"><i class="fas fa-edit"></i></button>
                    <button class="btn-delete" onclick="toggleUser('${u.id}')"><i class="fas ${u.active ? 'fa-ban' : 'fa-check'}"></i></button>
                </div>
            </td>
        </tr>
    `).join('');
    if (!db.users.length) tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--gray);padding:30px;">لا يوجد مستخدمين</td></tr>';
}

function showUserModal() {
    if (!hasPermission('users')) return alert('لا يوجد صلاحية!');
    document.getElementById('user-modal-title').textContent = 'إضافة مستخدم';
    document.getElementById('user-form').reset();
    document.getElementById('user-edit-id').value = '';
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('user-modal').classList.remove('hidden');
}

function editUser(id) { /* ... */ }
function toggleUser(id) {
    if (!hasPermission('users')) return;
    const db = getDB();
    const user = db.users.find(u => u.id === id);
    if (user) { user.active = !user.active; saveDB(db); addLog('تبديل حالة مستخدم', id); updateUsers(); }
}

// ===================== REPORTS =====================
function showReport(type) {
    const db = getDB();
    const content = document.getElementById('report-content');
    if (type === 'sales') {
        const totalSales = db.sales.reduce((s, x) => s + x.price, 0);
        const count = db.sales.length;
        content.innerHTML = `
            <h3>تقرير المبيعات</h3>
            <div class="stats-grid" style="margin-top:20px;">
                <div class="stat-card"><div class="stat-icon green"><i class="fas fa-handshake"></i></div><div class="stat-info"><h3>${count}</h3><p>عدد المبيعات</p></div></div>
                <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-money-bill-wave"></i></div><div class="stat-info"><h3>${formatNumber(totalSales)}</h3><p>إجمالي المبيعات</p></div></div>
                <div class="stat-card"><div class="stat-icon orange"><i class="fas fa-chart-line"></i></div><div class="stat-info"><h3>${count ? formatNumber(Math.round(totalSales / count)) : 0}</h3><p>متوسط السعر</p></div></div>
            </div>
            <div class="data-table-container" style="margin-top:20px;">
                <table class="data-table"><thead><tr><th>السيارة</th><th>العميل</th><th>السعر</th><th>التاريخ</th></tr></thead>
                <tbody>${db.sales.map(s => `<tr><td>${s.carName}</td><td>${s.customer}</td><td>${formatNumber(s.price)}</td><td>${s.date}</td></tr>`).join('')}</tbody>
            </div>
        `;
    } else if (type === 'purchases') {
        const total = db.purchases.reduce((s, x) => s + x.price, 0);
        content.innerHTML = `<h3>تقرير المشتريات</h3><div class="stats-grid" style="margin-top:20px;"><div class="stat-card"><div class="stat-icon orange"><i class="fas fa-cart-plus"></i></div><div class="stat-info"><h3>${db.purchases.length}</h3><p>عدد المشتريات</p></div></div><div class="stat-card"><div class="stat-icon blue"><i class="fas fa-money-bill-wave"></i></div><div class="stat-info"><h3>${formatNumber(total)}</h3><p>إجمالي المشتريات</p></div></div></div>`;
    } else if (type === 'inventory') {
        const totalItems = db.inventory.reduce((s, x) => s + x.qty, 0);
        const totalValue = db.inventory.reduce((s, x) => s + (x.qty * x.price), 0);
        content.innerHTML = `<h3>تقرير المخزن</h3><div class="stats-grid" style="margin-top:20px;"><div class="stat-card"><div class="stat-icon purple"><i class="fas fa-boxes"></i></div><div class="stat-info"><h3>${totalItems}</h3><p>إجمالي القطع</p></div></div><div class="stat-card"><div class="stat-icon blue"><i class="fas fa-money-bill-wave"></i></div><div class="stat-info"><h3>${formatNumber(totalValue)}</h3><p>قيمة المخزن</p></div></div></div><div class="data-table-container" style="margin-top:20px;"><table class="data-table"><thead><tr><th>القطعة</th><th>الكمية</th><th>القيمة</th></tr></thead><tbody>${db.inventory.map(i => `<tr><td>${i.name}</td><td>${i.qty}</td><td>${formatNumber(i.qty * i.price)}</td></tr>`).join('')}</tbody></table></div>`;
    } else if (type === 'financial') {
        const totalSales = db.sales.reduce((s, x) => s + x.price, 0);
        const totalPurchases = db.purchases.reduce((s, x) => s + x.price, 0);
        const totalExpenses = db.expenses.reduce((s, x) => s + x.amount, 0);
        const totalMaintenance = db.maintenance.reduce((s, x) => s + (x.cost || 0), 0);
        const net = totalSales - totalPurchases - totalExpenses - totalMaintenance;
        content.innerHTML = `
            <h3>التقرير المالي</h3>
            <div class="stats-grid" style="margin-top:20px;">
                <div class="stat-card"><div class="stat-icon green"><i class="fas fa-arrow-up"></i></div><div class="stat-info"><h3>${formatNumber(totalSales)}</h3><p>إجمالي المبيعات</p></div></div>
                <div class="stat-card"><div class="stat-icon red"><i class="fas fa-arrow-down"></i></div><div class="stat-info"><h3>${formatNumber(totalPurchases)}</h3><p>إجمالي المشتريات</p></div></div>
                <div class="stat-card"><div class="stat-icon orange"><i class="fas fa-money-bill-wave"></i></div><div class="stat-info"><h3>${formatNumber(totalExpenses)}</h3><p>إجمالي المصاريف</p></div></div>
                <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-wrench"></i></div><div class="stat-info"><h3>${formatNumber(totalMaintenance)}</h3><p>إجمالي الصيانة</p></div></div>
                <div class="stat-card"><div class="stat-icon ${net >= 0 ? 'green' : 'red'}"><i class="fas fa-balance-scale"></i></div><div class="stat-info"><h3>${formatNumber(net)}</h3><p>${net >= 0 ? 'صافي الربح' : 'صافي الخسارة'}</p></div></div>
            </div>
        `;
    }
}

// ===================== HELPERS =====================
function formatNumber(n) {
    return Number(n).toLocaleString('ar-YE');
}

function closeModal() {
    document.getElementById('modal-overlay').classList.add('hidden');
    document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden'));
}

function previewImages(input) {
    const preview = document.getElementById('image-preview');
    preview.innerHTML = '';
    Array.from(input.files).forEach(file => {
        const reader = new FileReader();
        reader.onload = e => { preview.innerHTML += `<img src="${e.target.result}" alt="">`; };
        reader.readAsDataURL(file);
    });
}

function previewPDF(input) {
    const preview = document.getElementById('pdf-preview');
    if (input.files.length) {
        const file = input.files[0];
        const reader = new FileReader();
        reader.onload = e => { preview.innerHTML = `<a href="${e.target.result}" target="_blank"><i class="fas fa-file-pdf"></i> ${file.name}</a>`; };
        reader.readAsDataURL(file);
    }
}

function exportData() {
    const data = JSON.stringify(getDB(), null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'almaryami_backup_' + new Date().toISOString().split('T')[0] + '.json';
    a.click();
    URL.revokeObjectURL(url);
    addLog('تصدير بيانات', 'تصدير نسخة احتياطية');
    alert('تم تصدير البيانات بنجاح!');
}

function importData(input) {
    if (!input.files.length) return;
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = e => {
        try {
            const data = JSON.parse(e.target.result);
            saveDB(data);
            currentDB = data;
            addLog('استيراد بيانات', 'استيراد نسخة احتياطية');
            alert('تم استيراد البيانات بنجاح!');
            location.reload();
        } catch (err) { alert('ملف غير صالح!'); }
    };
    reader.readAsText(file);
}

// ===================== EVENT LISTENERS =====================
document.addEventListener('DOMContentLoaded', function() {
    // Current date
    const dateEl = document.getElementById('current-date');
    if (dateEl) dateEl.textContent = new Date().toLocaleDateString('ar-YE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

    // Login
    document.getElementById('login-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        if (login(username, password)) {
            showScreen('dashboard');
            document.getElementById('current-user-name').textContent = currentUser.fullname;
            document.getElementById('user-role').textContent = ROLE_LABELS[currentUser.role] || currentUser.role;
            // Show admin items
            if (currentUser.role === 'admin' || currentUser.role === 'manager') {
                document.querySelectorAll('.nav-item.admin-only').forEach(el => el.style.display = 'flex');
            }
            // Hide restricted nav items
            document.querySelectorAll('.nav-item[data-page]').forEach(el => {
                const page = el.dataset.page;
                if (!hasPermission(page)) el.style.display = 'none';
            });
            showPage('home');
        } else {
            document.getElementById('login-error').textContent = 'اسم المستخدم أو كلمة المرور غير صحيحة!';
        }
    });

    // Logout
    document.getElementById('logout-btn').addEventListener('click', logout);

    // Navigation
    document.querySelectorAll('.nav-item[data-page]').forEach(el => {
        el.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.dataset.page;
            if (!hasPermission(page)) return alert('لا يوجد صلاحية!');
            showPage(page);
        });
    });

    // Car form
    document.getElementById('car-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const db = getDB();
        const id = document.getElementById('car-id').value || 'car' + Date.now();
        const images = Array.from(document.querySelectorAll('#image-preview img')).map(img => img.src);
        const pdfEl = document.querySelector('#pdf-preview a');
        const pdf = pdfEl ? pdfEl.href : '';
        const carData = {
            id: id,
            brand: document.getElementById('car-brand').value,
            model: document.getElementById('car-model').value,
            year: parseInt(document.getElementById('car-year').value),
            color: document.getElementById('car-color').value,
            plate: document.getElementById('car-plate').value,
            price: parseInt(document.getElementById('car-price').value),
            status: document.getElementById('car-status').value,
            fuel: document.getElementById('car-fuel').value,
            images: images,
            pdf: pdf,
            notes: document.getElementById('car-notes').value,
            dateAdded: new Date().toLocaleDateString('ar-YE')
        };
        const existing = db.cars.findIndex(c => c.id === id);
        if (existing >= 0) { db.cars[existing] = carData; addLog('تعديل سيارة', carData.model); }
        else { db.cars.push(carData); addLog('إضافة سيارة', carData.model); }
        saveDB(db);
        closeModal();
        updateCars();
        updateHomeStats();
    });

    // Sale form
    document.getElementById('sale-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const db = getDB();
        const carId = document.getElementById('sale-car').value;
        const car = db.cars.find(c => c.id === carId);
        const sale = {
            id: document.getElementById('sale-id').value || 's' + Date.now(),
            carId: carId,
            carName: car ? `${car.brand} ${car.model}` : '',
            customer: document.getElementById('sale-customer').value,
            phone: document.getElementById('sale-phone').value,
            price: parseInt(document.getElementById('sale-price').value),
            payment: document.getElementById('sale-payment').value,
            date: new Date().toLocaleDateString('ar-YE'),
            status: 'completed',
            notes: document.getElementById('sale-notes').value
        };
        const existing = db.sales.findIndex(s => s.id === sale.id);
        if (existing >= 0) db.sales[existing] = sale; else db.sales.push(sale);
        if (car) { car.status = 'sold'; }
        saveDB(db);
        addLog('عملية بيع', `${sale.carName} - ${sale.customer}`);
        closeModal();
        updateSales();
        updateCars();
        updateHomeStats();
    });

    // Purchase form
    document.getElementById('purchase-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const db = getDB();
        const purchase = {
            id: document.getElementById('purchase-id').value || 'p' + Date.now(),
            carName: document.getElementById('purchase-car').value,
            supplier: document.getElementById('purchase-supplier').value,
            phone: document.getElementById('purchase-phone').value,
            price: parseInt(document.getElementById('purchase-price').value),
            payment: document.getElementById('purchase-payment').value,
            date: new Date().toLocaleDateString('ar-YE'),
            status: 'completed',
            notes: document.getElementById('purchase-notes').value
        };
        const existing = db.purchases.findIndex(p => p.id === purchase.id);
        if (existing >= 0) db.purchases[existing] = purchase; else db.purchases.push(purchase);
        saveDB(db);
        addLog('عملية شراء', purchase.carName);
        closeModal();
        updatePurchases();
    });

    // Maintenance form
    document.getElementById('maintenance-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const db = getDB();
        const carId = document.getElementById('maintenance-car').value;
        const car = db.cars.find(c => c.id === carId);
        const maintenance = {
            id: document.getElementById('maintenance-id').value || 'm' + Date.now(),
            carId: carId,
            carName: car ? `${car.brand} ${car.model}` : '',
            type: document.getElementById('maintenance-type').value,
            cost: parseInt(document.getElementById('maintenance-cost').value) || 0,
            date: new Date().toLocaleDateString('ar-YE'),
            status: 'in-progress',
            desc: document.getElementById('maintenance-desc').value
        };
        const existing = db.maintenance.findIndex(m => m.id === maintenance.id);
        if (existing >= 0) db.maintenance[existing] = maintenance; else db.maintenance.push(maintenance);
        if (car) car.status = 'maintenance';
        saveDB(db);
        addLog('طلب صيانة', maintenance.carName);
        closeModal();
        updateMaintenance();
        updateCars();
        updateHomeStats();
    });

    // Inventory form
    document.getElementById('inventory-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const db = getDB();
        const item = {
            id: document.getElementById('inventory-id').value || 'inv' + Date.now(),
            name: document.getElementById('inventory-name').value,
            type: document.getElementById('inventory-type').value,
            qty: parseInt(document.getElementById('inventory-qty').value),
            price: parseInt(document.getElementById('inventory-price').value),
            location: document.getElementById('inventory-location').value
        };
        const existing = db.inventory.findIndex(i => i.id === item.id);
        if (existing >= 0) db.inventory[existing] = item; else db.inventory.push(item);
        saveDB(db);
        addLog('تعديل مخزن', item.name);
        closeModal();
        updateInventory();
        updateHomeStats();
    });

    // Invoice form
    document.getElementById('invoice-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const db = getDB();
        calculateInvoiceTotal();
        const items = Array.from(document.querySelectorAll('.invoice-item-row')).map(row => ({
            desc: row.querySelector('.item-desc').value,
            qty: parseInt(row.querySelector('.item-qty').value) || 0,
            price: parseInt(row.querySelector('.item-price').value) || 0,
            total: parseInt(row.querySelector('.item-total').value) || 0
        })).filter(i => i.desc);
        const invoice = {
            id: document.getElementById('invoice-id').value || 'inv' + Date.now(),
            number: document.getElementById('invoice-number').value,
            type: document.getElementById('invoice-type').value,
            party: document.getElementById('invoice-party').value,
            amount: parseInt(document.getElementById('invoice-amount').value) || 0,
            items: items,
            discount: parseInt(document.getElementById('invoice-discount').value) || 0,
            total: parseInt(document.getElementById('invoice-total').value) || 0,
            date: new Date().toLocaleDateString('ar-YE'),
            status: document.getElementById('invoice-status').value,
            notes: document.getElementById('invoice-notes').value
        };
        const existing = db.invoices.findIndex(i => i.id === invoice.id);
        if (existing >= 0) db.invoices[existing] = invoice; else db.invoices.push(invoice);
        saveDB(db);
        addLog('إنشاء فاتورة', invoice.number);
        closeModal();
        updateInvoices();
        updateHomeStats();
    });

    // Expense form
    document.getElementById('expense-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const db = getDB();
        const expense = {
            id: document.getElementById('expense-id').value || 'e' + Date.now(),
            item: document.getElementById('expense-item').value,
            type: document.getElementById('expense-type').value,
            amount: parseInt(document.getElementById('expense-amount').value),
            date: document.getElementById('expense-date').value,
            notes: document.getElementById('expense-notes').value
        };
        const existing = db.expenses.findIndex(ex => ex.id === expense.id);
        if (existing >= 0) db.expenses[existing] = expense; else db.expenses.push(expense);
        saveDB(db);
        addLog('إضافة مصروف', expense.item);
        closeModal();
        updateExpenses();
    });

    // User form
    document.getElementById('user-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const db = getDB();
        const id = document.getElementById('user-edit-id').value || 'u' + Date.now();
        const perms = {};
        Object.keys(PERM_MAP).forEach(p => {
            perms[p] = document.getElementById(PERM_MAP[p]).checked;
        });
        const user = {
            id: id,
            username: document.getElementById('user-username').value,
            fullname: document.getElementById('user-fullname').value,
            password: document.getElementById('user-password').value,
            role: document.getElementById('user-role').value,
            active: true,
            lastLogin: null,
            perms: perms
        };
        const existing = db.users.findIndex(u => u.id === id);
        if (existing >= 0) {
            const old = db.users[existing];
            user.password = user.password || old.password;
            user.active = old.active;
            user.lastLogin = old.lastLogin;
            db.users[existing] = user;
            addLog('تعديل مستخدم', user.username);
        } else {
            db.users.push(user);
            addLog('إضافة مستخدم', user.username);
        }
        saveDB(db);
        closeModal();
        updateUsers();
    });

    // Showroom settings
    document.getElementById('showroom-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const db = getDB();
        db.showroom.name = document.getElementById('setting-name').value;
        db.showroom.phone1 = document.getElementById('setting-phone1').value;
        db.showroom.phone2 = document.getElementById('setting-phone2').value;
        db.showroom.address = document.getElementById('setting-address').value;
        db.showroom.email = document.getElementById('setting-email').value;
        saveDB(db);
        addLog('تحديث بيانات المعرض', '');
        alert('تم حفظ البيانات بنجاح!');
    });

    // Invoice calculation
    document.getElementById('invoice-items').addEventListener('input', calculateInvoiceTotal);
    document.getElementById('invoice-discount').addEventListener('input', calculateInvoiceTotal);

    // Monitoring filters
    document.querySelectorAll('.btn-filter').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.btn-filter').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            updateMonitoring();
        });
    });

    // Search inputs
    document.getElementById('car-search')?.addEventListener('input', updateCars);
    document.getElementById('sale-search')?.addEventListener('input', updateSales);
    document.getElementById('purchase-search')?.addEventListener('input', updatePurchases);
    document.getElementById('maintenance-search')?.addEventListener('input', updateMaintenance);
    document.getElementById('inventory-search')?.addEventListener('input', updateInventory);
    document.getElementById('invoice-search')?.addEventListener('input', updateInvoices);
    document.getElementById('expense-search')?.addEventListener('input', updateExpenses);
});

// Auto-load data on startup
window.addEventListener('load', () => { currentDB = getDB(); });
